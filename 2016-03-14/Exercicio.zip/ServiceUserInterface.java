/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

public interface ServiceUserInterface {
    public void result(int valor);
    public void error();
}
