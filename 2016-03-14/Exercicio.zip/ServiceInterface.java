/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

public interface ServiceInterface {
    public void add(int op1, int op2);
    public void sub(int op1, int op2);
    public void times(int op1, int op2);
    public void div(int op1, int op2);
}
